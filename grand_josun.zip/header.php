<header>
        <h1><a href="index.html">그랜드조선부산호텔</a></h1>
        <nav>
            <a href="sub_rooms.html">RESERVATION<span><!-- icon --></span></a>
            <a href="sub_dining.html">OFFERS</a>
            <a href="sub_activity.html">MY RESERVATION</a>
        </nav>
        <!-- 모바일 네비게이션 -->
        <a href="#" id="mobile_nav">전체보기</a>
    </header>