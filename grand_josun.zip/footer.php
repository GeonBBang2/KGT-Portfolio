<footer>
        <div class="f_top">
            <div class="menu">
                <a href="#">이용약관</a>
                <a href="#">이메일무단수집금지</a>
                <a href="#">개인정보처리방침</a>
                <a href="#">호텔정책</a>
            </div>
            <a href="#" class="site">FAMILY SITES</a>
        </div>
        <div class="f_btm">
            <p>서울시 중구 소공로 106 대표이사 현재양 T.02-000-0000 F. 02-000-0000</p>
            <p>사업자 등록번호 104-00-00000 통신판매신고번호 중구 0623호</p>
            <p>&copy; 2020 SHINSEGAE CHOSUN HOTEL Co. All rights reserved.</p>
        </div>
    </footer>